/*
   合并后的 store
*/
import app from './modules/app';
import member from './modules/member';

const stores = {
   app,
   member
};

export default stores;
