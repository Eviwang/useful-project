// 其他路由配置
const {} = require('./utils.js');

// 有副作用的函数，给 server 上注册路由
module.exports = function mounted(server, DB) {};
