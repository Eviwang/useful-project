import aboutStore from './about';
import homeStore from './home';

const store = {
	aboutStore,
	homeStore
};

export default store;