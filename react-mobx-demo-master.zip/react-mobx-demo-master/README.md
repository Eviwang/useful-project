# react-mobx-demo
react+react-router+mobx+axios+less 搭建一个框架
 
> 此次框架搭建历程文章记载：https://www.jianshu.com/p/dcdb3884d73c

### 使用:

* 启动调试服务: `yarn start`
* 构建: `yarn build`

### 项目情况:

首页：【页面没有优化，请将就看】

![首页.png](https://upload-images.jianshu.io/upload_images/3453108-a0e196e2a8e6fe59.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

about页：【页面没有优化，请将就看】

![about页.png](https://upload-images.jianshu.io/upload_images/3453108-72ebf4e71bdd322d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
